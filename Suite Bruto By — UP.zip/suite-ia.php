<?php
/* ════════════════════════════════════════════════════════════════
   suite-ia.php — proxy da API da Anthropic para a Suíte UP · BRUTO

   ⚠️ ESTE ARQUIVO NUNCA VAI PRO GIT.
   Destino: bruto-secrets/API/suite-ia.php

   Por que existe:
   O navegador NÃO pode falar direto com api.anthropic.com — a chave
   ficaria visível no código-fonte da página. Todo pedido de IA passa
   por aqui, onde a chave vive no servidor e nunca sai dele.

   O que este arquivo protege, além da chave:
   1. Sessão obrigatória — quem não está logado não gasta token nenhum
   2. Teto de uso por pessoa/dia — um bug em loop não vira fatura
   3. Prompt montado no servidor — o navegador manda dados, não instruções
════════════════════════════════════════════════════════════════ */

declare(strict_types=1);

require_once __DIR__ . '/suite-auth.php';   // traz $pdo e suite_exige_sessao()

// ── 1. Só entra quem está autenticado ────────────────────────────
$usuario = suite_exige_sessao();            // devolve 401 e encerra se não estiver

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    suite_json(['erro' => 'Método não permitido.'], 405);
}

// ── 2. Chave da API ──────────────────────────────────────────────
// Reaproveita a mesma credencial já usada pelo Atendimento Técnico.
// Se o arquivo de chave tiver outro nome no servidor, ajuste aqui.
$ANTHROPIC_KEY = getenv('ANTHROPIC_API_KEY') ?: null;
if (!$ANTHROPIC_KEY && is_file(__DIR__ . '/chave-anthropic.php')) {
    $ANTHROPIC_KEY = require __DIR__ . '/chave-anthropic.php';  // deve dar `return 'sk-ant-...';`
}
if (!$ANTHROPIC_KEY) {
    suite_json(['erro' => 'Chave da API não configurada no servidor.'], 500);
}

// ── 3. Teto de uso diário por pessoa ─────────────────────────────
// A suíte chama IA em vários painéis. Um laço acidental no front-end
// poderia disparar centenas de chamadas sem ninguém perceber até a
// fatura chegar. Requer a tabela suite_ia_uso (SQL no rodapé).
const LIMITE_CHAMADAS_DIA = 120;

$st = $pdo->prepare(
    "SELECT COUNT(*) FROM suite_ia_uso
      WHERE usuario = ? AND quando > DATE_SUB(NOW(), INTERVAL 1 DAY)"
);
$st->execute([$usuario['usuario']]);
if ((int) $st->fetchColumn() >= LIMITE_CHAMADAS_DIA) {
    suite_json(['erro' => 'Limite diário de análises atingido. Tente amanhã.'], 429);
}

// ── 4. Entrada ───────────────────────────────────────────────────
$c          = suite_corpo();
$system     = trim((string) ($c['system'] ?? ''));
$payload    = $c['payload'] ?? null;
$max_tokens = (int) ($c['max_tokens'] ?? 1000);

if ($system === '' || $payload === null) {
    suite_json(['erro' => 'Requisição incompleta.'], 400);
}

// Tetos defensivos: o navegador é entrada não confiável, mesmo vindo
// de alguém logado. Pedido gigante = conta gigante.
$max_tokens   = max(100, min(2000, $max_tokens));
$system       = mb_substr($system, 0, 6000);
$payload_json = mb_substr(json_encode($payload, JSON_UNESCAPED_UNICODE), 0, 20000);

// Contexto da empresa é injetado aqui, no servidor — não vem do cliente.
$system = "Você atende a BRUTO, curadoria de revestimentos cerâmicos artesanais "
        . "(linhas Brick, Cimentício e Rockface), em São Paulo. "
        . "Tom direto e técnico, sem enrolação. Nunca prometa preço final, "
        . "desconto ou prazo exato — isso é sempre confirmado por um consultor.\n\n"
        . $system;

// ── 5. Chamada ───────────────────────────────────────────────────
$corpo = json_encode([
    'model'      => 'claude-sonnet-4-6',
    'max_tokens' => $max_tokens,
    'system'     => $system,
    'messages'   => [['role' => 'user', 'content' => $payload_json]],
], JSON_UNESCAPED_UNICODE);

$ch = curl_init('https://api.anthropic.com/v1/messages');
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST           => true,
    CURLOPT_POSTFIELDS     => $corpo,
    CURLOPT_TIMEOUT        => 45,
    CURLOPT_HTTPHEADER     => [
        'Content-Type: application/json',
        'x-api-key: ' . $ANTHROPIC_KEY,
        'anthropic-version: 2023-06-01',
    ],
]);

$resposta = curl_exec($ch);
$http     = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$erroCurl = curl_error($ch);
curl_close($ch);

// Registra o uso mesmo se falhou — tentativa também consome cota.
$pdo->prepare("INSERT INTO suite_ia_uso (usuario, quando, status) VALUES (?, NOW(), ?)")
    ->execute([$usuario['usuario'], (int) $http]);

if ($resposta === false) {
    error_log('suite-ia curl: ' . $erroCurl);
    suite_json(['erro' => 'Não consegui falar com o serviço de IA.'], 502);
}

$dados = json_decode($resposta, true);

if ($http !== 200) {
    // Loga o detalhe no servidor, devolve mensagem genérica ao navegador:
    // erro cru da API pode conter informação que não deve circular.
    error_log('suite-ia HTTP ' . $http . ': ' . mb_substr($resposta, 0, 500));
    suite_json(['erro' => 'O serviço de IA respondeu com erro.'], 502);
}

// Extrai o texto por TIPO de bloco, não por posição — a resposta pode
// trazer mais de um bloco e a ordem não é garantida.
$texto = '';
foreach (($dados['content'] ?? []) as $bloco) {
    if (($bloco['type'] ?? '') === 'text') {
        $texto .= $bloco['text'];
    }
}

if ($texto === '') {
    suite_json(['erro' => 'Resposta vazia do serviço de IA.'], 502);
}

suite_json(['texto' => $texto]);

/* ════════════════════════════════════════════════════════════════
   SQL necessário — rodar uma vez

   CREATE TABLE IF NOT EXISTS suite_ia_uso (
     id      INT AUTO_INCREMENT PRIMARY KEY,
     usuario VARCHAR(60) NOT NULL,
     quando  DATETIME    NOT NULL,
     status  SMALLINT    NOT NULL DEFAULT 0,
     INDEX idx_uso (usuario, quando)
   );

   -- Limpeza opcional
   -- DELETE FROM suite_ia_uso WHERE quando < DATE_SUB(NOW(), INTERVAL 90 DAY);

   ── Sobre a chave da API ────────────────────────────────────────
   Reaproveite a chave que o Atendimento Técnico já usa. Se ela estiver
   em bruto-secrets/API/chat.php embutida, o mais limpo é extrair para
   um arquivo próprio:

       bruto-secrets/API/chave-anthropic.php
       <?php return 'sk-ant-...';

   e fazer os dois (chat.php e suite-ia.php) lerem do mesmo lugar —
   assim uma rotação de chave é feita em um arquivo só.
════════════════════════════════════════════════════════════════ */
