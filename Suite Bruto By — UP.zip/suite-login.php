<?php
/* bruto-secrets/API/suite-login.php — NUNCA vai pro Git */
require_once __DIR__ . '/suite-auth.php';
suite_login($pdo);
