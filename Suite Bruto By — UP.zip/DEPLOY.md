# Implantação da Suíte UP · BRUTO — Checklist

> Ordem importa. Cada fase deixa a suíte num estado estável e usável —
> nunca ficamos com meio-caminho quebrado no ar.

---

## Fase 0 — Pré-requisitos (uma vez, antes de tudo)

- [x] Subdomínio confirmado: `up.brutoceramica.com.br`
- [ ] Criar a pasta isolada no Hostinger (mesmo padrão do Atendimento/OS)
- [ ] Rodar `migracao.sql` inteiro no phpMyAdmin do banco `u764636502_bruto_interno`
- [ ] `DESCRIBE usuarios;` — confirmar se existe `senha_hash`. Se não, rodar o
      `ALTER TABLE` comentado no topo do `migracao.sql`
- [ ] Gerar hash de senha de cada pessoa **no servidor** (nunca em site externo):
      `php -r "echo password_hash('senha-escolhida', PASSWORD_BCRYPT, ['cost'=>12]);"`
      e colar em `usuarios.senha_hash`
- [ ] Copiar os 6 arquivos de `_para-bruto-secrets/` para `bruto-secrets/API/`
      no servidor (**nunca** para dentro de `public_html`)
- [ ] Extrair a chave da Anthropic para `bruto-secrets/API/chave-anthropic.php`
      (reaproveitando a que o Atendimento já usa) — ver rodapé de `suite-ia.php`

## Fase 1 — Suíte no ar, protegida, ainda em modo demo

Objetivo: equipe já consegue acessar por login real; dado ainda é de demonstração.
Risco: zero — nenhum dado real exposto ainda.

- [ ] Subir todo o conteúdo da pasta raiz do zip (exceto `_para-bruto-secrets/`
      e `ARQUITETURA-BRUTO.md`/`migracao.sql`/`DEPLOY.md`, que ficam só de referência)
- [ ] Testar: abrir `up-dash.html` direto pela URL deve redirecionar pro login
- [ ] Testar login com um usuário real
- [ ] Testar `upLogout()` (botão Sair na sidebar)
- [ ] Confirmar que o `robots.txt` e o `.htaccess` subiram (arquivos ocultos —
      fácil esquecer no upload por FTP/painel)
- [ ] `DEMO_MODE` continua `true` em `config.js` nesta fase

Nesta fase a suíte já é útil: a equipe pode navegar, entender os módulos,
validar que os KPIs fazem sentido — só que ainda com dados de exemplo.

⚠️ **Decidido: virada tudo de uma vez.** `DEMO_MODE` continua sendo uma chave
global única em `config.js` — sem checagem por módulo. Consequência prática:
**todas as pontes PHP das Fases 2 a 6 precisam estar prontas e testadas antes
de `DEMO_MODE` virar `false`.** Até lá, mesmo com o endpoint do Flow pronto,
a suíte inteira continua mostrando dado de demonstração. É o trade-off aceito
em troca de simplicidade — a Fase 1 (suíte no ar, protegida) dura mais tempo.

## Fase 2 — UP·Flow com dado real (menor risco, maior retorno)

Por quê primeiro: `ordens_servico` já existe, schema já confirmado, **zero
tabela nova**. É o módulo com menos trabalho e mais valor imediato — mas a
virada em si só acontece junto com as Fases 3 a 6, na Fase 6.

- [x] Escrever `bruto-secrets/API/suite-ordens.php` — lê `ordens_servico`,
      formata como o `up-flow.html` espera
- [x] Ponte pública `api/ordens.php` (padrão de 10 linhas)
- [ ] Endpoint pronto e testado isoladamente (com `DEMO_MODE` ainda `true`,
      testar via `fetch` manual no console) — não vira `false` ainda

## Fase 3 — UP·Lead

- [ ] `lead_pipeline` e `amostra_envio` já existem (Fase 0)
- [ ] `suite-leads.php` — join entre sessões do Atendimento (`historico`) e
      `lead_pipeline`
- [ ] Todo pedido salvo em `amostra_envio` fica visível aqui também
- [ ] Migrar os 3 leads de demonstração perde sentido — a lista passa a vir
      só do banco

## Fase 4 — UP·Vault

- [ ] `suite-transacoes.php` — CRUD simples sobre a tabela `transacoes`
- [ ] Lançar as primeiras transações reais manualmente (não há integração
      bancária automática ainda — é entrada manual, como uma planilha)

## Fase 5 — UP·Base, UP·Team, UP·Voice

- [ ] `base_docs` — os 7 documentos já escritos nesta sessão viram o
      conteúdo inicial (`INSERT` único, não precisa recriar)
- [ ] `membros` — **precisa dos nomes reais da equipe antes de rodar**
      (hoje são placeholders: Diego/Fernanda/Lucas)
- [ ] `voice_alertas` — depende de UP·Lead e UP·Vault já estarem reais,
      porque é isso que gera os alertas

## Fase 6 — UP·Dash e UP·GOS

Por último de propósito: os dois **agregam** os outros módulos. Ligar antes
da hora mostraria número errado com aparência de número certo — pior que
mostrar dado de demonstração claramente rotulado como tal.

- [ ] Cron semanal calcula e grava em `pulse_semanal`
- [ ] UP·Dash e UP·GOS passam a ler o snapshot, não recalcular a cada carga
- [ ] **Só agora:** com Flow, Lead, Vault, Base, Team, Voice, Dash e GOS
      todos testados isoladamente, `DEMO_MODE = false` em `config.js` —
      a única virada, de uma vez só, como decidido

## Fase 7 — Cron dos alertas proativos (UP·Voice)

- [ ] Job periódico (cron nativo do Hostinger) varre `lead_pipeline` e
      `transacoes` procurando o que bate nos SLAs do `BRUTO_OPS.slas`
- [ ] Alertas entram em `voice_alertas` como `pendente`
- [ ] Aprovação manual continua ativa (`voice_require_approval` em
      `CLIENT_CONFIG`) até a equipe confiar no critério

---

## O que travar antes de qualquer fase além da 1

- **Nomes reais da equipe** (Fase 5) — hoje Diego/Fernanda/Lucas são
  placeholders meus, não confirmados
- **`CLIENT_CONFIG.rafael_whatsapp`** — em branco, necessário pro UP·Voice
- **Confirmação do subdomínio final**

---

## Nota de implementação — UP·Flow (Fase 2, escrito em 29/07/2026)

`suite-ordens.php` só faz `SELECT` em `ordens_servico`. Nunca `INSERT`/`UPDATE`/
`DELETE` — quem avança um pedido continua sendo a ferramenta Ordem de Serviço,
não a suíte.

**Pedidos reais entram travados na tela.** `ordens_servico` tem um único campo
`status` (pendente/em produção/concluído/cancelado); o UP·Flow mostra 5 etapas
visuais. A tradução de um pro outro é aproximação do backend, não dado real —
por isso essas etapas aparecem com um 🔒 e o número da OS, e clicar nelas
mostra um aviso em vez de editar. Só **projetos internos** (criados pelo botão
"Novo projeto" dentro da suíte, sem OS por trás) continuam com etapa editável.

**"Atrasado" também é aproximação.** O cálculo usa dias corridos desde
`criado_em` comparado ao teto de 15 dias úteis do `BRUTO_OPS.slas`, não dias
úteis exatos (exigiria calendário de feriados). Erra para mais — marca
atrasado com folga, nunca o contrário.

**De quebra, corrigido um bug represado:** "Novo projeto" empurrava pro array
em memória e sumia no F5 — o mesmo problema que Base, Team e Core ainda têm.
UP·Flow agora salva no `localStorage` (mesmo padrão do Lead e do Vault).
Base/Team/Core continuam pendentes dessa mesma correção.

---

## Nota de implementação — UP·Lead (Fase 3, escrito em 07/08/2026)

`suite-leads.php` só faz `SELECT` em `sessoes_atendimento` — nunca escreve
nela. Toda escrita (etapa, valor estimado, m², linha, responsável) vai
para `lead_pipeline`, via `INSERT ... ON DUPLICATE KEY UPDATE`.

**A estrutura real de `sessoes_atendimento` foi conferida no phpMyAdmin**
antes de escrever qualquer linha de código — schema real: `id`,
`usuario_id`, `cliente_nome`, `cliente_tipo`, `preview`, `msg_count`,
`tags`, `arquivado`, `payload` (JSON da conversa completa), `criado_em`
(bigint, ms), `atualizado_em`.

**Mudança de arquitetura em relação à versão demo:** a demo tinha
"leads" e "deals" como duas coleções separadas, ligadas só pelo nome em
texto. Isso não existe na base real — não fazia sentido preservar. Agora
o **pipeline é derivado da mesma lista de leads**, agrupado por `etapa`:
cada card do kanban é 1 lead (real ou manual), não um registro à parte.
"Criar deal" pra um lead existente atualiza a etapa/valor **desse
lead** — antes criava um registro novo desconectado.

**Campos "IA" da demo (`ai_intencao`, `lead_score`, `temperatura`)
eram só mock — nunca foram calculados de verdade.** Nesta versão:
- `temperatura` e `prioridade`: heurística por etapa do funil (documentada
  linha a linha no PHP, não fingida como IA)
- `lead_score`: heurística por etapa + volume de mensagens
- `ai_intencao` / `ai_qualificacao`: só aparecem quando existem de fato
  (leads manuais que passaram pela classificação por IA do formulário
  "Novo lead"). Leads reais não têm isso — o painel de contato esconde
  a caixa de análise quando os campos vêm vazios, em vez de mostrar
  "undefined".

**Leads manuais** (criados pelo botão "Novo lead" ou deal sem lead
vinculado) seguem o mesmo padrão do UP·Flow: ficam em `localStorage`,
tag `origem:'manual'`, nunca gravados em `sessoes_atendimento`.

**Conversa completa vem junto no `listar`** (não é buscada sob demanda) —
simplifica o front-end às custas de payload maior por carga de página.
Se o volume de sessões crescer muito, a ação `obter_conversa` já está
pronta no backend pra virar sob demanda sem precisar reescrever o resto.

**Ainda não usado nesta fase:** a tabela `amostra_envio` já existe
(migração da Fase 0), mas nenhum endpoint ainda lê/escreve nela — fica
pra quando o rastreio de amostra por modelo entrar em pauta.

---

## Nota de implementação — UP·Vault (Fase 4, escrito em 07/08/2026)

A mais simples das fases até agora: não existe controle financeiro real
em nenhum outro lugar do banco pra ler ou dar join. `transacoes` nasceu
vazia na migração da Fase 0 — `suite-vault.php` é CRUD direto (`listar` /
`criar`), sem heurística, sem tabela de origem pra respeitar.

**Único cálculo do lado do servidor:** `vencimento_7d` é recalculado a
partir da data (não confiamos no que o navegador manda) — só marca como
"vencendo" despesas com data entre hoje e daqui a 7 dias.

**A meta do mês não precisa de chamada ao servidor.** Já vem carregada
no navegador via `config.js` (`CLIENT_CONFIG.meta_mrr`) — inventar uma
tabela `client_config` só pra isso, como a versão demo original supunha,
seria complexidade sem necessidade.

**Zero transações reais até alguém lançar a primeira.** Isso é esperado
— diferente de Lead/Flow, que herdam dado que já existe, o Vault começa
genuinamente vazio até a equipe começar a lançar receitas e despesas.

---

## Nota de implementação — UP·Base e UP·Team (Fase 5, escrito em 08/08/2026)

Ambos CRUD direto, mesmo padrão do Vault — sem heurística, sem join.

**UP·Base é diferente dos outros: não começa vazio.** Os 8 SOPs escritos
com o Rafael ao longo das sessões anteriores não são mock — são política
real da Bruto (qualificação de lead, escalonamento, frete, variação
natural, cadência de follow-up, catálogo, controle de amostra, deploy).
`seed-base-docs.sql` popula a tabela com esse conteúdo real no primeiro
`INSERT` — não é preciso recriar nada na mão.

**UP·Team semeado com as 4 pessoas reais** (Rafael, Gabriel, Luana,
Mateus) via `seed-membros.sql`. Contadores de tarefa começam **zerados**
de propósito — inventar números de atividade que não existem seria pior
que não ter o módulo.

⚠️ Rodar os dois seeds no phpMyAdmin **antes** de considerar essas fases
prontas — sem eles, `base_docs` e `membros` ficam vazios mesmo com o
código certo no ar.

---

## Nota técnica — seeds SQL rodados manualmente (08/08/2026)

Os dois seeds da Fase 5 foram rodados direto no editor SQL do phpMyAdmin
(colando o conteúdo, sem usar Importar). Achado que vale registrar pra
qualquer seed futuro com coluna JSON:

**Dentro de uma string MySQL de aspas simples, `\"` é resolvido pelo
MySQL virando só `"`.** Isso destrói o escape que uma string JSON com
aspas internas precisa pra continuar válida — o INSERT falha com
`#4025 CONSTRAINT base_docs.steps failed` (a constraint automática que o
MySQL cria pra colunas JSON). A correção: usar `\\"` (duas barras) no
SQL sempre que o JSON tiver aspas internas — o MySQL desfaz um nível de
escape e sobra exatamente `\"` no valor armazenado, que é o que o JSON
precisa.

Os arquivos `.sql` gerados programaticamente (via Python, escapando
corretamente) não têm esse problema — só apareceu ao digitar o SQL à
mão direto no editor do phpMyAdmin.

**Resultado final:** `base_docs` com os 8 documentos reais, `membros`
com as 4 pessoas reais — ambos confirmados via `SELECT * FROM` depois
do INSERT, não só pela mensagem de sucesso.

---

## Nota de implementação — UP·Voice, UP·Dash, UP·GOS (Fase 6, escrito em 08/08/2026)

**A mais interligada das fases** — Dash e GOS agora compartilham o
mesmo backend (`suite-pulso.php`) e o mesmo algoritmo de cálculo
(`window.calcularGOS`, extraído pro `nav.js`). Antes, cada um tinha
sua cópia — agora é uma implementação só, então se o algoritmo mudar,
muda num lugar e os dois módulos continuam batendo o mesmo número.

**UP·GOS**: o algoritmo do health score é 100% client-side desde a
demo — regras determinísticas, documentadas linha a linha, nunca foi
IA. Só trocamos `MOCK_SOURCE` (dado de exemplo) por `api/pulso.php`
(ação `fonte`, dado real de `transacoes`, `lead_pipeline`,
`sessoes_atendimento`, `ordens_servico`, `membros`). O histórico de
5 semanas que a demo mostrava era fictício — agora aparece só a
semana atual, honestamente, até o cron da Fase 7 começar a acumular
`pulse_semanal`.

**UP·Dash**: usa o mesmo `suite-pulso.php` (ação `pulso`) pra montar
os KPIs, e chama `window.calcularGOS` separadamente pra pegar o
health score — nunca duas implementações do cálculo rodando em
paralelo. **Os "Insights — UP·Mind" ficam vazios em produção.**
Isso não é bug: UP·Mind está deliberadamente adiado (conversa
anterior sobre "qual é a função do UP·Mind"), e inventar insight
fabricado seria pior que não ter nenhum.

**Aproximações documentadas no `suite-pulso.php`** (não fingidas como
precisas): "leads respondidos em 24h" usa `msg_count >= 2` como
indício de resposta (não há análise por mensagem); "amostras
convertidas" usa `etapa = 'ganho'` como proxy (o rastreio de verdade,
por modelo, é o papel da tabela `amostra_envio`, ainda não conectada
a nenhum módulo). "Processos" (UP·Core) fica com o valor neutro (60)
porque não existe fonte real — não inventamos dado de um módulo que
nem está ativo na navegação.

**UP·Voice — leia isto antes de confiar no botão "Marcar como
enviado":**

⚠️ **Não existe envio de WhatsApp de verdade configurado.**
`CLIENT_CONFIG.evolution_api_url` está vazio. O botão "Marcar como
enviado" só muda o status no banco pra `enviado` — é um registro de
intenção da equipe, **nada é disparado pro cliente**. Configurar o
envio real é trabalho futuro, fora do escopo desta fase, e precisa
ser comunicado com clareza pra equipe não achar que o cliente já foi
avisado quando não foi.

O que **é** real: o motor de detecção (`acao: 'verificar'`) roda 4
regras determinísticas contra as tabelas de verdade — orçamento
parado 48h+, amostra sem retorno 7d+, conta a vencer sem saldo
suficiente, padrão de atraso na equipe — e grava os alertas
encontrados. Tem proteção contra duplicata: não recria um alerta com
o mesmo título se já existe um em aberto há menos de 24h.

**Mensagem do alerta é um template determinístico nesta versão, não
escrita por IA.** Em demo, a mensagem é redigida por IA
(`window.callClaude`); em produção, por ora, é texto fixo. Dá pra
evoluir depois — não é essencial pra esta fase fechar.

---

## Todas as fases prontas — próximo passo é a virada do DEMO_MODE

Com Flow, Lead, Vault, Base, Team, Voice e Dash/GOS todos com backend
real escrito, falta:

1. Instalar esta Fase 6 (arquivos + rodar teste isolado de cada ação)
2. Testar cada módulo com `DEMO_MODE` ainda `true` (endpoints
   funcionam em paralelo, não afetam a tela ainda)
3. **Só depois disso**: `DEMO_MODE = false` em `config.js` — a virada
   única, de uma vez, como decidido lá no início desta fase de deploy

---

## Bug real encontrado em produção — colação divergente (08/08/2026)

Ao testar os endpoints de verdade (não só sintaxe), `suite-leads.php` e
`suite-pulso.php` davam erro 500 silencioso assim que `lead_pipeline`
passou a ter linhas de verdade (antes, com a tabela vazia, o bug ficava
escondido). Causa: `#1267 - Combinação ilegal de collations`.

`sessoes_atendimento.id` (tabela do Atendimento, criada antes desta
suíte) usa `utf8mb4_uca1400_ai_ci`. As tabelas que criamos na migração
(`lead_pipeline.sessao_id`, `amostra_envio.sessao_id`) ficaram com
`utf8mb4_unicode_ci` — a colação padrão do CREATE TABLE, sem eu
verificar contra o que a tabela referenciada já usava. Qualquer JOIN
entre elas quebra.

**Corrigido via ALTER TABLE direto no banco** (não precisou reinstalar
nada):
```sql
ALTER TABLE lead_pipeline MODIFY sessao_id VARCHAR(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_uca1400_ai_ci NOT NULL;
ALTER TABLE amostra_envio MODIFY sessao_id VARCHAR(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_uca1400_ai_ci NOT NULL;
```

**Lição pra qualquer tabela nova que referencie uma tabela já
existente**: sempre conferir `SHOW FULL COLUMNS` (ou a aba Estrutura
do phpMyAdmin) da tabela de origem ANTES de criar a coluna que vai
comparar/juntar com ela — não confiar na colação padrão do CREATE
TABLE.

**Pendência de baixa prioridade, não corrigida ainda**: `transacoes.ordem_servico_id`
foi criada como VARCHAR(40), mas `ordens_servico.id` é `int(11)` — tipos
diferentes (não é colação, é tipo mesmo). Como essa coluna ainda não é
usada em nenhum JOIN, não corrigi agora — só documentando pra não
esquecer quando alguém for de fato ligar transação a uma ordem de
serviço específica.

**Como o bug de tipo em `suite-leads.php` foi pego** (separado do bug
de colação): instalei PHP-CLI 8.3 no ambiente de trabalho e testei as
funções de verdade com dados simulados (sessões sem pipeline, mensagens
malformadas, timestamps não numéricos) em vez de só ler o código
visualmente. Vale manter esse hábito nas próximas fases — inspeção
visual não pega `TypeError` que só aparece com `strict_types=1` e dado
real.

---

## Decisões do Rafael — UP·Voice por e-mail e UP·Flow escrevendo (08/08/2026)

**UP·Voice: WhatsApp trocado por e-mail.** A integração Evolution API
estava banindo contas do WhatsApp — não é confiável pra produção agora.
`suite-voice.php` passou a mandar e-mail de verdade via `mail()` do PHP
pra `contato@brutoceramica.com.br` quando um alerta é aprovado. Isso
substitui o aviso antigo ("não manda nada de verdade ainda") — agora
manda, só que por e-mail, não WhatsApp. Se um dia a Evolution API
voltar a ser confiável, trocar o canal é uma mudança isolada nesse
arquivo, não peça o resto da suíte.

**UP·Flow: a suíte agora TAMBÉM avança pedido.** Antes, `suite-ordens.php`
só fazia `SELECT` — só a ferramenta Ordem de Serviço escrevia. Rafael
decidiu que o Flow deveria poder avançar também. As duas ferramentas
agora escrevem no mesmo campo `status`, mesmo vocabulário — não é uma
cópia paralela do dado.

**Como o avanço mapeia de volta pro status real:** marcar uma das 5
etapas sintéticas não bate 1:1 com um dos 4 status reais (granularidades
diferentes). Regra, espelhando o mapeamento inverso já usado pra
desenhar as etapas: marcar etapa 0 ou 1 → `pendente`; etapa 2 ou 3 →
`em produção`; etapa 4 (Confirmação de entrega) → `concluído`. Testado
com PHP-CLI real, 8 casos (todos os índices + casos de erro), todos
bateram com o esperado antes de instalar.

O badge "🔒 Somente leitura" no card de pedido virou só o número da OS,
sem cadeado — a trava de fato não existe mais.

**Dívida técnica de baixa prioridade, não corrigida agora:** o painel
de status do UP·Voice (topo da tela) ainda mostra "WhatsApp oficial
Bruto" / "WhatsApp do responsável" com números de telefone e um limite
diário de envio — todo esse desenho pressupõe o canal antigo. Não
atrapalha o e-mail funcionar, mas fica com informação cosmética
desatualizada até alguém repaginar esse painel especificamente.

---

## Bug pego no teste de ponta a ponta pós-virada (08/08/2026)

Primeira vez rodando com `DEMO_MODE=false` de verdade, apareceu algo
que só ficaria visível com dado real: a narrativa da semana (IA)
dizia "faturamento acima do ritmo" enquanto o card ao lado mostrava
R$ 0. Causa: `destaque_positivo` no prompt da narrativa era uma
string fixa (`'Faturamento do mês acima do ritmo da meta'`), herdada
da versão demo, nunca trocada por um cálculo real. Em modo demo isso
não aparecia porque o `MOCK_PULSE` sempre tinha números que batiam
com essa frase por coincidência.

Corrigido: `destaque_positivo` agora é calculado comparando receita
realizada no mês contra uma fração proporcional da meta (baseada em
quantos dias do mês já passaram) — três resultados possíveis: "ainda
sem receita lançada", "acima do ritmo" ou "abaixo do ritmo esperado".

**Lição:** dado mockado que "por acaso" bate com texto fixo esconde
esse tipo de acoplamento até o primeiro teste com dado real zerado ou
diferente do exemplo. Vale escanear outros prompts de IA na suíte
(UP·Voice já não tem esse problema — a mensagem lá é template
determinístico, não IA, desde a decisão desta sessão) procurando
outros valores fixos que deveriam ser dinâmicos.

---

## Segundo bug pego no teste de ponta a ponta (08/08/2026)

`UP·Base`: clicar num documento não abria nada, sem erro visível.
Causa: `docs.find(x=>x.id===id)` usava comparação estrita (`===`), mas
o `id` que chega no `onclick` vem como string (`selectDoc('${d.id}')`
sempre gera string), enquanto `d.id` no array carregado do backend é
number (`(int) $d['id']` em `suite-base.php`). `"1" === 1` é `false`
em JS — a busca falhava silenciosamente (`if(!d) return;`), sem
console.error, sem nada visível além de "não acontece nada".

Em modo demo isso nunca apareceu porque os IDs mockados eram strings
dos dois lados (`'doc1'`). Só ficou visível com ID numérico real do
banco. Corrigido com `String(x.id)===String(id)` nos dois pontos de
comparação (seleção e destaque do item ativo na lista).

**Checagem feita nos outros módulos:** `up-flow.html` está seguro
porque os IDs já nascem como string no backend (`'os_' . $id`).
`up-team.html` e `up-vault.html` não têm esse padrão de seleção
clicável por ID, então não têm esse risco.

---

## Terceiro e quarto bugs pegos no teste de ponta a ponta (08/08/2026)

**UP·Voice** — o painel "Status da integração" ainda mostrava
"Evolution API — Não conectado (modo demo)" e campos de telefone
vazios, mesmo já estando em modo e-mail (decisão desta sessão).
Confuso pra quem for usar, mesmo não sendo um erro funcional.
Trocado por "Canal: E-mail" e "Destinatário:
contato@brutoceramica.com.br". Removidas duas linhas de JS que
setavam `status-founder-phone`/`status-rafael-phone` — como os
elementos correspondentes saíram do HTML, essas linhas
travariam a inicialização inteira da tela com `null.textContent`.

**UP·GOS** — o histórico de health score mostrava "Semana undefined ·
2026-08-08". Causa: o campo `semana` foi gerado como uma data simples
(`"2026-08-08"`), mas o template espera formato ISO `AAAA-Wss`
(`h.semana.split('-W')`). Corrigido com uma função de cálculo de
semana ISO 8601 (`suiteSemanaISO`), testada com PHP... digo, com
Node.js contra casos de borda de ano (29/12/2025 → corretamente vira
2026-W01) antes de instalar.

**Resumo dos 4 bugs desta rodada de teste real, todos do mesmo tipo
de causa raiz:** dado mockado "por coincidência" batia com suposições
que só quebram com dado de produção de verdade — timestamp de tipo
errado, string fixa em vez de cálculo, comparação de tipo entre
string e number, formato de data incompatível com o template. Nenhum
deles apareceu em teste isolado por endpoint; só apareceram rodando a
suíte inteira, logado, clicando de verdade.

---

## Pedidos do Rafael pós-virada (08/08/2026): filtro no Flow + follow-up com IA

**UP·Flow — filtro de período + busca.** Adicionados pills "Todos /
Hoje / 7 dias / Mês" (filtrando por `p.inicio`, data real de criação
do pedido) e um campo de busca por OS/cliente/nome — tudo client-side,
já que a lista inteira de pedidos já vem carregada em memória. Sem
mudança no backend.

**UP·Lead — colar conversa real do WhatsApp pra sugestão de IA.**
Pergunta do Rafael: dado que a suíte só lê de `sessoes_atendimento`
(decisão da Fase 3), essa fronteira ainda era viável? Sim — e a
solução nem chega perto dela. Criada uma tabela **nova, só da
suíte**: `followup_anexos` (id, sessao_id, texto, criado_por,
criado_em), ligada por `sessao_id` com a colação certa
(`utf8mb4_uca1400_ai_ci`) desde a criação — lição da Fase 6, não
precisou de ALTER TABLE depois dessa vez.

Descoberta no caminho: existe um `historico.php` real no Atendimento
que já faz `salvar`/`listar`/`obter`/`excluir`/`arquivar` de sessão —
mas exige login **do Atendimento** (`require_login()` próprio,
diferente do `suite-auth.php`). A suíte não tem essa credencial e não
deveria ganhar — por isso a solução foi uma tabela satélite, não
escrever ali.

No UP·Lead, cada conversa real agora tem uma seção "Follow-up real
(WhatsApp)": textarea pra colar a conversa, lista do que já foi
colado, e um botão "✨ Sugerir abordagem" que manda o histórico da IA
+ tudo que foi colado pro `window.callClaude`, pedindo sugestão de
próximo passo — mesmo padrão de IA client-side já usado no resto da
suíte (nunca chamada direta do servidor pra Anthropic, exceto pelo
`chat.php` que já existe no Atendimento e não é nosso).

---

## Rodada grande de pedidos do Rafael (08/08/2026)

**1. Controle de acesso por papel.** Atendentes (papel='atendente' no
banco) só acessam UP·Lead e UP·Base — e dentro do Lead, só veem as
próprias sessões (`s.usuario_id = ?`), não as de todo mundo.

Duas camadas, não uma só:
- **Front-end (conveniência)**: `nav.js` esconde os módulos vedados do
  menu; `auth-guard.js` redireciona pra `up-lead.html` se um atendente
  tentar abrir a URL de um módulo vedado direto.
- **Back-end (proteção de verdade)**: `suite_bloqueia_atendente()`
  (nova função em `suite-auth.php`) devolve 403 nos backends de Vault,
  Team, Voice, Dash/GOS e Flow quando o papel é 'atendente' — mesmo que
  alguém desligue o JS ou bata na API direto, os dados não saem.
  `suite-leads.php` (Lead) e `suite-base.php` (Base) continuam abertos,
  mas o Lead agora filtra por `usuario_id` quando o papel é atendente.

Pra isso funcionar, `suite_exige_sessao()` passou a devolver também o
`id` numérico do usuário (antes só devolvia usuario/nome/papel) — sem
isso não dava pra filtrar `sessoes_atendimento.usuario_id = ?`.

⚠️ **Pendência real que precisa de decisão do Rafael**: o Gabriel está
cadastrado como `papel = 'atendente'` no banco (foi o único valor
disponível na hora de criar a conta dele, na Fase 0). Com essa
restrição nova, ele ficaria preso só em Lead+Base também — o que
provavelmente não é a intenção, já que ele é sócio. Precisa decidir:
mudar o papel dele pra 'admin' (perde a distinção entre "atendente
comum" e "sócio"), ou criar um papel novo tipo 'socio' com regras
próprias. Não mudei o papel dele sozinho — é decisão de negócio, não
técnica.

**2. Botão "Atualizar suíte"** — fixo no canto superior direito,
injetado pelo `nav.js` (por isso aparece em todo módulo sem precisar
editar cada header individualmente). Recarrega a página atual — não
existe estado compartilhado entre módulos pra "atualizar" além disso,
já que cada um é uma página HTML separada, não um SPA.

**3. WhatsApp real substitui a conversa espelhada.** Antes, a conversa
colada ficava exibida JUNTO com a conversa do widget de IA. Agora, se
existe follow-up real anexado, ele substitui — a conversa do widget
fica arquivada, visível só na caixa de anexos abaixo. Aceita upload de
`.txt` (exportação nativa do WhatsApp, "Exportar conversa → sem
mídia") OU colar o texto direto — os dois alimentam o mesmo textarea e
seguem pro mesmo backend.

Parser de exportação do WhatsApp (`parseWhatsApp`, client-side) cobre
os dois formatos comuns (Android "hífen" e iOS "colchetes"), trata
mensagem multi-linha corretamente, e tem fallback: se o texto colado
não bater nenhum dos dois formatos, mostra como uma mensagem única em
vez de simplesmente sumir com o que foi colado. Testado com Node.js
antes de instalar — casos normais, multi-linha, sem nome de cliente,
vazio, e null/undefined.

Direção da mensagem (inbound/outbound) é heurística: compara o nome do
remetente da linha do WhatsApp com o nome do cliente cadastrado — não
é 100% à prova de erro (ex: se o cliente salvou o número com apelido
diferente do nome cadastrado), mas é o sinal mais forte disponível sem
pedir confirmação manual por mensagem.

**4. Registrado como pendência, não construído agora**: tutorial
guiado (onboarding) no primeiro acesso.

**5. Vault com IA lendo arquivo/imagem em lote — ainda não iniciado.**
É o pedido mais complexo desta rodada (upload de arquivo, decisão de
armazenamento, IA com visão, processamento em lote). Proposta de
arquitetura being discutida com o Rafael antes de começar a construir.
