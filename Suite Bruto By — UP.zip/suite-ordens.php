<?php
/* ════════════════════════════════════════════════════════════════
   suite-ordens.php — UP·Flow lendo pedidos reais

   ⚠️ ESTE ARQUIVO NUNCA VAI PRO GIT.
   Destino: bruto-secrets/API/suite-ordens.php

   O QUE ESTE ARQUIVO FAZ: SELECT em `ordens_servico`. Só isso.
   NUNCA faz INSERT, UPDATE ou DELETE nessa tabela — quem cria e
   avança pedido é a ferramenta Ordem de Serviço, não a suíte.
   Se um dia a suíte precisar escrever, isso é uma decisão nova,
   não uma extensão silenciosa deste arquivo.

   POR QUE SINTETIZAR ETAPAS: `ordens_servico` tem um único campo
   `status` (pendente / em produção / concluído / cancelado). O
   UP·Flow exibe 5 etapas visuais. A tradução de um pra outro é uma
   aproximação — documentada abaixo — não um dado que existe de
   verdade no banco. Por isso o front-end trava a edição dessas
   etapas para pedidos (ver origem:'pedido' em up-flow.html):
   editar uma etapa sintética não pode parecer que está editando
   o pedido real.
════════════════════════════════════════════════════════════════ */

declare(strict_types=1);

require_once __DIR__ . '/suite-auth.php';   // traz $pdo e suite_exige_sessao()

suite_exige_sessao();   // 401 e encerra se não estiver logado

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    suite_json(['erro' => 'Método não permitido.'], 405);
}

$c    = suite_corpo();
$acao = (string) ($c['acao'] ?? 'listar');

if ($acao !== 'listar') {
    suite_json(['erro' => 'Ação não suportada.'], 400);
}

// ── Nomes das 5 etapas exibidas no UP·Flow ────────────────────────
const SUITE_ETAPAS_PEDIDO = [
    'Confirmação de pedido e pagamento',
    'Produção/separação na fábrica parceira',
    'Controle de qualidade e embalagem',
    'Frete e transporte',
    'Confirmação de entrega',
];

/**
 * Traduz o status real (uma string) nas 5 etapas visuais do UP·Flow.
 * Aproximação deliberada — ver comentário no topo do arquivo.
 */
function suite_etapas_por_status(string $status, int $diasCorridos): array {
    // Índice da etapa "corrente" por status. -1 = nenhuma iniciada ainda.
    $indiceAtual = match ($status) {
        'pendente'     => 0,  // confirmação em andamento
        'em produção'  => 2,  // produção/separação e vindo pra qualidade
        'concluído'    => 4,  // tudo passou
        'cancelado'    => -1, // não avança nada
        default        => 0,
    };

    $etapas = [];
    foreach (SUITE_ETAPAS_PEDIDO as $i => $nome) {
        if ($status === 'cancelado') {
            $st = 'pendente';
        } elseif ($status === 'concluído') {
            $st = 'concluido';
        } elseif ($i < $indiceAtual) {
            $st = 'concluido';
        } elseif ($i === $indiceAtual) {
            $st = 'ativo';
        } else {
            $st = 'pendente';
        }
        $etapas[] = ['id' => 'e' . $i, 'nome' => $nome, 'status' => $st, 'responsavel' => null];
    }
    return $etapas;
}

/**
 * Status do card (ativo/atrasado/concluido/cancelado) a partir do status
 * real + tempo decorrido. SLA de referência: BRUTO_OPS.slas.entrega_dias_uteis
 * (7 a 15 dias úteis). Aqui usamos dias corridos como aproximação simples —
 * calcular dia útil exato em SQL/PHP exige calendário de feriados, que não
 * existe hoje. Erra pra mais (mais liberal em marcar "atrasado"), não pra menos.
 */
function suite_status_card(string $status, int $diasCorridos): string {
    if ($status === 'cancelado') return 'cancelado';
    if ($status === 'concluído') return 'concluido';
    return $diasCorridos > 15 ? 'atrasado' : 'ativo';
}

function suite_resumo_itens($itensRaw): string {
    $itens = is_string($itensRaw) ? json_decode($itensRaw, true) : $itensRaw;
    if (!is_array($itens) || count($itens) === 0) return 'Pedido';
    $primeiro = $itens[0]['descricao'] ?? $itens[0]['nome'] ?? 'Item';
    $resto = count($itens) - 1;
    return $resto > 0 ? "{$primeiro} +{$resto} item" . ($resto > 1 ? 's' : '') : $primeiro;
}

// ── Consulta ───────────────────────────────────────────────────────
// Só leitura. Ordenado do mais recente pro mais antigo, limitado a 100
// pra não devolver o histórico inteiro numa carga só.
$st = $pdo->query(
    "SELECT id, numero_os, cliente_nome, cliente_contato, criado_por,
            criado_em, itens, total_geral, observacoes, status
       FROM ordens_servico
      ORDER BY criado_em DESC
      LIMIT 100"
);
$linhas = $st->fetchAll(PDO::FETCH_ASSOC);

$pedidos = array_map(function (array $o) {
    $criadoEm      = new DateTimeImmutable((string) $o['criado_em']);
    $diasCorridos  = $criadoEm->diff(new DateTimeImmutable())->days;
    $previsao      = $criadoEm->modify('+15 days');   // aproximação — ver nota acima

    return [
        'id'           => 'os_' . $o['id'],
        'origem'       => 'pedido',
        'os_numero'    => $o['numero_os'],
        'nome'         => 'Pedido — ' . suite_resumo_itens($o['itens']),
        'cliente'      => $o['cliente_nome'],
        'status'       => suite_status_card((string) $o['status'], $diasCorridos),
        'inicio'       => $criadoEm->format('Y-m-d'),
        'previsao'     => $previsao->format('Y-m-d'),
        'concluido_em' => $o['status'] === 'concluído' ? $criadoEm->format('Y-m-d') : null,
        'valor'        => $o['total_geral'],
        'ai_suggestion'=> null,
        'etapas'       => suite_etapas_por_status((string) $o['status'], $diasCorridos),
    ];
}, $linhas);

suite_json(['pedidos' => $pedidos]);
