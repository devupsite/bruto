<?php
/* bruto-secrets/API/suite-me.php — NUNCA vai pro Git */
require_once __DIR__ . '/suite-auth.php';
suite_me();
