<?php
/* ════════════════════════════════════════════════════════════════
   suite-auth.php — núcleo de autenticação da Suíte UP · BRUTO

   ⚠️ ESTE ARQUIVO NUNCA VAI PRO GIT.
   Destino no servidor: bruto-secrets/API/suite-auth.php
   (pasta irmã de public_html, fora do alcance do deploy automático)

   Os três arquivos suite-login.php, suite-me.php e suite-logout.php
   apenas dão require neste aqui e chamam a função correspondente.
════════════════════════════════════════════════════════════════ */

declare(strict_types=1);

// ── Conexão: reaproveita a credencial que já existe ──────────────
// Não duplicar senha de banco. O arquivo de conexão das outras
// ferramentas já vive em bruto-secrets/ — aponte para ele.
require_once __DIR__ . '/conexao.php';   // deve expor $pdo (PDO com ERRMODE_EXCEPTION)

// ── Sessão endurecida ────────────────────────────────────────────
function suite_boot_sessao(): void {
    if (session_status() === PHP_SESSION_ACTIVE) return;

    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
          || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');

    session_name('BRUTOSUITE');
    session_set_cookie_params([
        'lifetime' => 0,          // morre ao fechar o navegador
        'path'     => '/',
        'httponly' => true,       // JS não lê o cookie → reduz risco de XSS
        'secure'   => $https,     // só trafega em HTTPS
        'samesite' => 'Strict',   // não vaza em requisição vinda de fora
    ]);
    session_start();
}

function suite_json($dados, int $status = 200): void {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('X-Content-Type-Options: nosniff');
    header('Cache-Control: no-store');
    echo json_encode($dados, JSON_UNESCAPED_UNICODE);
    exit;
}

function suite_corpo(): array {
    $raw = file_get_contents('php://input') ?: '';
    $d = json_decode($raw, true);
    return is_array($d) ? $d : [];
}

/* ── Freio de força bruta ────────────────────────────────────────
   Sem isso, um script tenta senha sem parar. Guarda tentativa por
   usuário + IP e aplica espera crescente. Requer a tabela
   suite_login_tentativas (SQL no final deste arquivo). */
function suite_checa_bloqueio(PDO $pdo, string $usuario, string $ip): void {
    $st = $pdo->prepare(
        "SELECT COUNT(*) FROM suite_login_tentativas
          WHERE (usuario = ? OR ip = ?)
            AND sucesso = 0
            AND quando > DATE_SUB(NOW(), INTERVAL 15 MINUTE)"
    );
    $st->execute([$usuario, $ip]);
    $falhas = (int) $st->fetchColumn();

    if ($falhas >= 8) {
        suite_json(['erro' => 'Muitas tentativas. Tente novamente em 15 minutos.'], 429);
    }
    if ($falhas >= 3) {
        sleep(min(5, $falhas - 2));   // atraso progressivo
    }
}

function suite_registra_tentativa(PDO $pdo, string $usuario, string $ip, bool $ok): void {
    $st = $pdo->prepare(
        "INSERT INTO suite_login_tentativas (usuario, ip, sucesso, quando) VALUES (?, ?, ?, NOW())"
    );
    $st->execute([mb_substr($usuario, 0, 60), $ip, $ok ? 1 : 0]);
}

/* ════════════════ LOGIN ════════════════ */
function suite_login(PDO $pdo): void {
    suite_boot_sessao();

    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
        suite_json(['erro' => 'Método não permitido.'], 405);
    }

    $c       = suite_corpo();
    $usuario = trim((string) ($c['usuario'] ?? ''));
    $senha   = (string) ($c['senha'] ?? '');
    $ip      = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';

    if ($usuario === '' || $senha === '') {
        suite_json(['erro' => 'Informe usuário e senha.'], 400);
    }

    suite_checa_bloqueio($pdo, $usuario, $ip);

    // Reaproveita a tabela `usuarios` que já existe (mesma do Atendimento).
    $st = $pdo->prepare(
        "SELECT id, usuario, nome, papel, senha_hash, ativo
           FROM usuarios WHERE usuario = ? LIMIT 1"
    );
    $st->execute([$usuario]);
    $u = $st->fetch(PDO::FETCH_ASSOC);

    // password_verify roda mesmo sem usuário encontrado, contra um hash
    // descartável — assim o tempo de resposta não denuncia se o usuário
    // existe ou não (evita enumeração de contas).
    $hash = $u['senha_hash'] ?? '$2y$12$invalidoinvalidoinvalidoinvalidoinvalidoinvalidoinvalido';
    $ok   = password_verify($senha, $hash) && $u && (int) $u['ativo'] === 1;

    suite_registra_tentativa($pdo, $usuario, $ip, $ok);

    if (!$ok) {
        // Mensagem propositalmente genérica: não revela se errou usuário ou senha.
        suite_json(['erro' => 'Usuário ou senha inválidos.'], 401);
    }

    // Renova o id da sessão no login → impede fixação de sessão
    session_regenerate_id(true);

    $_SESSION['suite_uid']    = (int) $u['id'];
    $_SESSION['suite_user']   = $u['usuario'];
    $_SESSION['suite_nome']   = $u['nome'];
    $_SESSION['suite_papel']  = $u['papel'];
    $_SESSION['suite_desde']  = time();
    $_SESSION['suite_visto']  = time();
    $_SESSION['suite_ua']     = substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 120);

    suite_json([
        'ok'      => true,
        'usuario' => $u['usuario'],
        'nome'    => $u['nome'],
        'papel'   => $u['papel'],
    ]);
}

/* ════════════════ ME (quem está logado) ════════════════
   Chamado pelo auth-guard.js em toda página. É também a função que
   os endpoints de DADOS devem chamar antes de devolver qualquer coisa. */
function suite_exige_sessao(): array {
    suite_boot_sessao();

    if (empty($_SESSION['suite_uid'])) {
        suite_json(['erro' => 'Não autenticado.'], 401);
    }

    // Expira por inatividade (8h) e por idade absoluta (12h)
    $agora = time();
    if ($agora - ($_SESSION['suite_visto'] ?? 0) > 8 * 3600
     || $agora - ($_SESSION['suite_desde'] ?? 0) > 12 * 3600) {
        suite_destroi_sessao();
        suite_json(['erro' => 'Sessão expirada.'], 401);
    }

    // Troca de navegador com o mesmo cookie é sinal de roubo de sessão
    if (($_SESSION['suite_ua'] ?? '') !== substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 120)) {
        suite_destroi_sessao();
        suite_json(['erro' => 'Sessão inválida.'], 401);
    }

    $_SESSION['suite_visto'] = $agora;

    return [
        'usuario' => $_SESSION['suite_user'],
        'nome'    => $_SESSION['suite_nome'],
        'papel'   => $_SESSION['suite_papel'],
    ];
}

function suite_me(): void {
    suite_json(suite_exige_sessao());
}

/* ════════════════ LOGOUT ════════════════ */
function suite_destroi_sessao(): void {
    suite_boot_sessao();
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
    }
    session_destroy();
}

function suite_logout(): void {
    suite_destroi_sessao();
    suite_json(['ok' => true]);
}

/* ════════════════════════════════════════════════════════════════
   SQL necessário — rodar uma vez no phpMyAdmin

   -- 1) Tabela de tentativas (freio de força bruta)
   CREATE TABLE IF NOT EXISTS suite_login_tentativas (
     id      INT AUTO_INCREMENT PRIMARY KEY,
     usuario VARCHAR(60) NOT NULL,
     ip      VARCHAR(45) NOT NULL,
     sucesso TINYINT(1)  NOT NULL DEFAULT 0,
     quando  DATETIME    NOT NULL,
     INDEX idx_busca (usuario, ip, quando)
   );

   -- 2) Confira se `usuarios` já tem coluna de hash de senha.
   --    Se o Atendimento usa Basic Auth de pasta, pode não ter:
   --    DESCRIBE usuarios;
   --    Se faltar:
   --    ALTER TABLE usuarios ADD COLUMN senha_hash VARCHAR(255) NULL AFTER usuario;

   -- 3) Limpeza periódica (opcional, evita a tabela crescer sem fim)
   --    DELETE FROM suite_login_tentativas WHERE quando < DATE_SUB(NOW(), INTERVAL 30 DAY);

   ── Como criar a senha de cada pessoa ──────────────────────────
   NUNCA guarde senha em texto puro, nem gere hash por site aleatório
   na internet. Rode no próprio servidor (ou em qualquer PHP local):

       php -r "echo password_hash('a-senha-escolhida', PASSWORD_BCRYPT, ['cost'=>12]);"

   Copie a saída (começa com \$2y\$12\$) para a coluna senha_hash do
   usuário correspondente. Cada pessoa com seu próprio usuário —
   login compartilhado destrói a rastreabilidade de quem fez o quê.
════════════════════════════════════════════════════════════════ */
