<?php
/* bruto-secrets/API/suite-logout.php — NUNCA vai pro Git */
require_once __DIR__ . '/suite-auth.php';
suite_logout();
