# Implantação da Suíte UP · BRUTO — Checklist

> Ordem importa. Cada fase deixa a suíte num estado estável e usável —
> nunca ficamos com meio-caminho quebrado no ar.

---

## Fase 0 — Pré-requisitos (uma vez, antes de tudo)

- [x] Subdomínio confirmado: `up.brutoceramica.com.br`
- [ ] Criar a pasta isolada no Hostinger (mesmo padrão do Atendimento/OS)
- [ ] Rodar `migracao.sql` inteiro no phpMyAdmin do banco `u764636502_bruto_interno`
- [ ] `DESCRIBE usuarios;` — confirmar se existe `senha_hash`. Se não, rodar o
      `ALTER TABLE` comentado no topo do `migracao.sql`
- [ ] Gerar hash de senha de cada pessoa **no servidor** (nunca em site externo):
      `php -r "echo password_hash('senha-escolhida', PASSWORD_BCRYPT, ['cost'=>12]);"`
      e colar em `usuarios.senha_hash`
- [ ] Copiar os 6 arquivos de `_para-bruto-secrets/` para `bruto-secrets/API/`
      no servidor (**nunca** para dentro de `public_html`)
- [ ] Extrair a chave da Anthropic para `bruto-secrets/API/chave-anthropic.php`
      (reaproveitando a que o Atendimento já usa) — ver rodapé de `suite-ia.php`

## Fase 1 — Suíte no ar, protegida, ainda em modo demo

Objetivo: equipe já consegue acessar por login real; dado ainda é de demonstração.
Risco: zero — nenhum dado real exposto ainda.

- [ ] Subir todo o conteúdo da pasta raiz do zip (exceto `_para-bruto-secrets/`
      e `ARQUITETURA-BRUTO.md`/`migracao.sql`/`DEPLOY.md`, que ficam só de referência)
- [ ] Testar: abrir `up-dash.html` direto pela URL deve redirecionar pro login
- [ ] Testar login com um usuário real
- [ ] Testar `upLogout()` (botão Sair na sidebar)
- [ ] Confirmar que o `robots.txt` e o `.htaccess` subiram (arquivos ocultos —
      fácil esquecer no upload por FTP/painel)
- [ ] `DEMO_MODE` continua `true` em `config.js` nesta fase

Nesta fase a suíte já é útil: a equipe pode navegar, entender os módulos,
validar que os KPIs fazem sentido — só que ainda com dados de exemplo.

⚠️ **Decidido: virada tudo de uma vez.** `DEMO_MODE` continua sendo uma chave
global única em `config.js` — sem checagem por módulo. Consequência prática:
**todas as pontes PHP das Fases 2 a 6 precisam estar prontas e testadas antes
de `DEMO_MODE` virar `false`.** Até lá, mesmo com o endpoint do Flow pronto,
a suíte inteira continua mostrando dado de demonstração. É o trade-off aceito
em troca de simplicidade — a Fase 1 (suíte no ar, protegida) dura mais tempo.

## Fase 2 — UP·Flow com dado real (menor risco, maior retorno)

Por quê primeiro: `ordens_servico` já existe, schema já confirmado, **zero
tabela nova**. É o módulo com menos trabalho e mais valor imediato — mas a
virada em si só acontece junto com as Fases 3 a 6, na Fase 6.

- [x] Escrever `bruto-secrets/API/suite-ordens.php` — lê `ordens_servico`,
      formata como o `up-flow.html` espera
- [x] Ponte pública `api/ordens.php` (padrão de 10 linhas)
- [ ] Endpoint pronto e testado isoladamente (com `DEMO_MODE` ainda `true`,
      testar via `fetch` manual no console) — não vira `false` ainda

## Fase 3 — UP·Lead

- [ ] `lead_pipeline` e `amostra_envio` já existem (Fase 0)
- [ ] `suite-leads.php` — join entre sessões do Atendimento (`historico`) e
      `lead_pipeline`
- [ ] Todo pedido salvo em `amostra_envio` fica visível aqui também
- [ ] Migrar os 3 leads de demonstração perde sentido — a lista passa a vir
      só do banco

## Fase 4 — UP·Vault

- [ ] `suite-transacoes.php` — CRUD simples sobre a tabela `transacoes`
- [ ] Lançar as primeiras transações reais manualmente (não há integração
      bancária automática ainda — é entrada manual, como uma planilha)

## Fase 5 — UP·Base, UP·Team, UP·Voice

- [ ] `base_docs` — os 7 documentos já escritos nesta sessão viram o
      conteúdo inicial (`INSERT` único, não precisa recriar)
- [ ] `membros` — **precisa dos nomes reais da equipe antes de rodar**
      (hoje são placeholders: Diego/Fernanda/Lucas)
- [ ] `voice_alertas` — depende de UP·Lead e UP·Vault já estarem reais,
      porque é isso que gera os alertas

## Fase 6 — UP·Dash e UP·GOS

Por último de propósito: os dois **agregam** os outros módulos. Ligar antes
da hora mostraria número errado com aparência de número certo — pior que
mostrar dado de demonstração claramente rotulado como tal.

- [ ] Cron semanal calcula e grava em `pulse_semanal`
- [ ] UP·Dash e UP·GOS passam a ler o snapshot, não recalcular a cada carga
- [ ] **Só agora:** com Flow, Lead, Vault, Base, Team, Voice, Dash e GOS
      todos testados isoladamente, `DEMO_MODE = false` em `config.js` —
      a única virada, de uma vez só, como decidido

## Fase 7 — Cron dos alertas proativos (UP·Voice)

- [ ] Job periódico (cron nativo do Hostinger) varre `lead_pipeline` e
      `transacoes` procurando o que bate nos SLAs do `BRUTO_OPS.slas`
- [ ] Alertas entram em `voice_alertas` como `pendente`
- [ ] Aprovação manual continua ativa (`voice_require_approval` em
      `CLIENT_CONFIG`) até a equipe confiar no critério

---

## O que travar antes de qualquer fase além da 1

- **Nomes reais da equipe** (Fase 5) — hoje Diego/Fernanda/Lucas são
  placeholders meus, não confirmados
- **`CLIENT_CONFIG.rafael_whatsapp`** — em branco, necessário pro UP·Voice
- **Confirmação do subdomínio final**

---

## Nota de implementação — UP·Flow (Fase 2, escrito em 29/07/2026)

`suite-ordens.php` só faz `SELECT` em `ordens_servico`. Nunca `INSERT`/`UPDATE`/
`DELETE` — quem avança um pedido continua sendo a ferramenta Ordem de Serviço,
não a suíte.

**Pedidos reais entram travados na tela.** `ordens_servico` tem um único campo
`status` (pendente/em produção/concluído/cancelado); o UP·Flow mostra 5 etapas
visuais. A tradução de um pro outro é aproximação do backend, não dado real —
por isso essas etapas aparecem com um 🔒 e o número da OS, e clicar nelas
mostra um aviso em vez de editar. Só **projetos internos** (criados pelo botão
"Novo projeto" dentro da suíte, sem OS por trás) continuam com etapa editável.

**"Atrasado" também é aproximação.** O cálculo usa dias corridos desde
`criado_em` comparado ao teto de 15 dias úteis do `BRUTO_OPS.slas`, não dias
úteis exatos (exigiria calendário de feriados). Erra para mais — marca
atrasado com folga, nunca o contrário.

**De quebra, corrigido um bug represado:** "Novo projeto" empurrava pro array
em memória e sumia no F5 — o mesmo problema que Base, Team e Core ainda têm.
UP·Flow agora salva no `localStorage` (mesmo padrão do Lead e do Vault).
Base/Team/Core continuam pendentes dessa mesma correção.
